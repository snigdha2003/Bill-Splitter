import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Transaction } from '../new-transaction/transaction.model';
import { Observable } from 'rxjs';
import { TransactionRoommate } from '../new-transaction/transactionRoommate.model';

@Injectable({
    providedIn: 'root'
})
export class TransactionService{

    transacSummArr : Transaction[] = [];

    baseUrl: string = 'http://localhost:8082/api';

    constructor(private httpClient: HttpClient){}

    saveTransaction(transactions: Transaction[]): Observable<any>{
        return this.httpClient.post(`${this,this.baseUrl}` + `/transactions`, transactions);
    }
    getTransSumm(phone: string): Observable<any>{
        return this.httpClient.get(`${this.baseUrl}` + `/transacSumm/${phone}`);
    }
    getTransListYouOwe(loggedInUserPhone : string) : Observable<any>{
        return this.httpClient.get(`${this.baseUrl}` + `/transacListYouOwe/${loggedInUserPhone}`);
    }
    getTransListOweYou(loggedInUserPhone : string) : Observable<any>{
        return this.httpClient.get(`${this.baseUrl}` + `/transacListOweYou/${loggedInUserPhone}`);
    }
    saveTransRoommate(tranRoommateArr : TransactionRoommate[]) : Observable<any>{
        return this.httpClient.post(`${this.baseUrl}` + '/transRoommate', tranRoommateArr);
    }

    getAllTransactions(loggedInUserPhone : string): Observable<any>{
        return this.httpClient.get(`${this.baseUrl}` + `/allTransactions/${loggedInUserPhone}`);
    }
    getTransDetails(transBy : string, totAmt : number,
         category : string, date : Date): Observable<any>{
       
        return this.httpClient.get(`${this.baseUrl}` + `/transDetails/${transBy}/${totAmt}/${category}/${date}`);

    }
}