import { Roommates } from '../roommates/roommates.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class RoommateService{

  roommateToEdit: Roommates;
  indexToEdit: number;

  baseUrl: string = 'http://localhost:8082/api';
  loggedInUserRoomNum: string;
  loggedInUserName: string;
  loggedInUserPhone: string;
  newUserPhone: string;

    constructor(private httpClient: HttpClient){

    }

    saveRoommates(roommateAdded: Roommates[]): Observable<Object>{
         console.log("SERvice " + roommateAdded[0].name + " "+ roommateAdded[0].phone 
            + " "+roommateAdded[0].gender);
        return this.httpClient.post('http://localhost:8082/api/roommates',roommateAdded);
        
    }

    getAll() : Observable<any> {
      return this.httpClient.get(`${this.baseUrl}` + `/getAllRoommates`);
    }

    getUserByPhNum(phone: string) : Observable<any>{
      return this.httpClient.get(`${this.baseUrl}` + `/getUserByPhone/${phone}`);
    }
    
    getByRoomNum(roomNum: string) : Observable<any>{
      return this.httpClient.get(`${this.baseUrl}` + `/getByRoomNum/${roomNum}`);
    }
    getByName(name:string): Observable<any>{
      return this.httpClient.get(`${this.baseUrl}` + `/getByName/${name}`);
    }
    updateRoommate(phone: string, editedRoommate: Roommates): Observable<any>{
      return this.httpClient.put(`${this.baseUrl}` + `/editRoommate/${phone}`, editedRoommate);
    }

    deleteRoommate(roomateToDelete: Roommates){
      const options = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
        body:{
          roomateToDelete,
        }
      }
      let phone = roomateToDelete.phone;
      return this.httpClient.delete(`${this.baseUrl}` + `/deleteRoommate/${phone}`);

    }
} 