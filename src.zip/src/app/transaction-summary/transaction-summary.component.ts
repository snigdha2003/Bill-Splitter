import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../services/transaction.service';
import { RoommateService } from '../services/roommateService.service';
import { Transaction } from '../new-transaction/transaction.model';
import { Router } from '@angular/router';
import { TransactionRoommate } from '../new-transaction/transactionRoommate.model';

@Component({
  selector: 'app-transaction-summary',
  templateUrl: './transaction-summary.component.html',
  styleUrls: ['./transaction-summary.component.css']
})
export class TransactionSummaryComponent implements OnInit {

  transacSummOweYou : TransactionRoommate;
  transacSummYouOwe : TransactionRoommate;
  transacListYouOwe : TransactionRoommate[] = [];
  transacListOweYou : TransactionRoommate[] = [];

  noTransactions:string;

  constructor(private transServ: TransactionService, private roommateServ: RoommateService,
                private router: Router) { }

  ngOnInit(): void {
     this.transServ.getTransSumm(this.roommateServ.loggedInUserPhone).subscribe(
        data => {
          if(data.length > 0){
          this.transacSummOweYou = data[0];
          this.transacSummYouOwe = data[1];
          this.transServ.transacSummArr = data;
          this.noTransactions = '';
          
          }else{
            this.noTransactions="No Transactions To Show"
          }
        }
      )

     //you owe
     this.transServ.getTransListYouOwe(this.roommateServ.loggedInUserPhone).subscribe(
      data => {
        this.transacListYouOwe = data;
      }
    )

    //owe you
    this.transServ.getTransListOweYou(this.roommateServ.loggedInUserPhone).subscribe(
      data => {
        this.transacListOweYou = data;
      }
    )

  }

  getAllTrans(){
    this.router.navigate(['/transDetail']);
  }
  backToLogin(){
    this.router.navigate(['']);
  }

}
