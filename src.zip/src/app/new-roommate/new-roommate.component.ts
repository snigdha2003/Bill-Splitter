import { Component, OnInit, ViewChild } from '@angular/core';
import { RoommateService } from '../services/roommateService.service';
import { Roommates } from '../roommates/roommates.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-new-roommate',
  templateUrl: './new-roommate.component.html',
  styleUrls: ['./new-roommate.component.css']
})
export class NewRoommateComponent implements OnInit {

  @ViewChild('f') form:NgForm;
  phone: string;
  allRoommates: Roommates[];
  invalidEntry: string;
  errOccured: string;
  registeredSucc: string;

  constructor(private roommateServ: RoommateService) { }

  ngOnInit(): void {
    this.phone = this.roommateServ.newUserPhone;
  }

  registerNewUser(){
   let newUser: Roommates[]=[];
   newUser.push(new Roommates('',this.form.value.name, this.form.value.gender,this.phone,this.phone));
   this.roommateServ.saveRoommates(newUser).subscribe(
     data =>{
       this.registeredSucc = 'User Registered Successfully'
     },
     err =>{
       this.errOccured = 'Error Occurred. Please try again after sometime'
     }
   )
  }

}
