import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewRoommateComponent } from './new-roommate.component';

describe('NewRoommateComponent', () => {
  let component: NewRoommateComponent;
  let fixture: ComponentFixture<NewRoommateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewRoommateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewRoommateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
