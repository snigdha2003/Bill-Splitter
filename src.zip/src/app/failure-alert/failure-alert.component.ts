import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-failure-alert',
  templateUrl: './failure-alert.component.html',
  styleUrls: ['./failure-alert.component.css']
})
export class FailureAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
