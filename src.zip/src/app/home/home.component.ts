import { Component, OnInit } from '@angular/core';
import { RoommateService } from '../services/roommateService.service';
import { Roommates } from '../roommates/roommates.model';
import { Route, Router } from '@angular/router';
import { TouchSequence } from 'selenium-webdriver';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  users: Roommates;
  userNotFoundError : string;
  roommateNotFoundError : string;
  errOccured: string;

  constructor(private roommateServ: RoommateService, private router: Router) { }

  ngOnInit(): void {
  }

  getUserTransDetails(phNum: string){
    this.userNotFoundError = '';
    this.roommateNotFoundError = '';
    this.roommateServ.getUserByPhNum(phNum).subscribe(
      data => {
        this.users = data;
        if(!this.users){
          this.userNotFoundError = "No User Found. Please Register";
          this.roommateServ.newUserPhone = phNum;
           
        }
        else{
           this.roommateServ.loggedInUserRoomNum = this.users.roomNumber;
           this.roommateServ.loggedInUserName = this.users.name;
           this.roommateServ.loggedInUserPhone = phNum;
           this.roommateServ.getByRoomNum(phNum).subscribe(
             data =>{
                if(null != data && data.length==1){
                  this.roommateNotFoundError = "No Roomates Found. Please Add Roommates"
                }else{
                this.router.navigate(['/showTransacSumm']);
              }
             },
             err =>{
              this.errOccured = 'Erro Occured. Please try again after some time'
             }
            
           )
          
         }
          
        console.log('GET USERRTRRR' + this.roommateServ.loggedInUserPhone);
       
      }
      
    )
    
   
  }

  registerNewUser(){
    this.router.navigate(['/newRoommateRegister']);
  }
  addRoomateFromHome(){
   this.router.navigate(['/roommates']);
  }

}
