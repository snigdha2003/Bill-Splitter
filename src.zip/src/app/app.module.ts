import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRouting } from './app-router.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';


import { HomeComponent } from './home/home.component';
import { RoommatesComponent } from './roommates/roommates.component';
import { NewTransactionComponent } from './new-transaction/new-transaction.component';
import { FormsModule } from '@angular/forms';
import { RoommateService } from './services/roommateService.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Route } from '@angular/compiler/src/core';
import { Routes, RouterModule } from '@angular/router';
import { RoommateEditComponent } from './roommate-edit/roommate-edit.component';
import { TransactionSummaryComponent } from './transaction-summary/transaction-summary.component';
import { MatIconModule } from '@angular/material/icon';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { TransactionDetailComponent } from './transaction-detail/transaction-detail.component';
import { NewRoommateComponent } from './new-roommate/new-roommate.component';

const routes: Routes = [
 
  {path:'home', component:HomeComponent},
  {path:'roommates', component:RoommatesComponent},
  {path:'newTrans', component:NewTransactionComponent},
  {path:'edit', component:RoommateEditComponent},
  {path:'showTransacSumm', component:TransactionSummaryComponent},
  {path:'transDetail', component:TransactionDetailComponent},
  {path:'newRoommateRegister', component:NewRoommateComponent},
  {path:'', component: HomeComponent},
  {path:'**', component: RoommatesComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    RoommatesComponent,
    NewTransactionComponent,
    RoommateEditComponent,
    TransactionSummaryComponent,
    TransactionDetailComponent,
    NewRoommateComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatIconModule,
    BrowserAnimationsModule,
    MatSlideToggleModule,
    AppRouting
  ],
  providers: [RoommateService],
  bootstrap: [AppComponent]
})


    



export class AppModule { 

 
}
