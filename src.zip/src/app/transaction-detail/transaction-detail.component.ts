import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../services/transaction.service';
import { Transaction } from '../new-transaction/transaction.model';
import { RoommateService } from '../services/roommateService.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction-detail',
  templateUrl: './transaction-detail.component.html',
  styleUrls: ['./transaction-detail.component.css']
})
export class TransactionDetailComponent implements OnInit {

  transDetail: Transaction[] = [];
  eachTransDetail : Transaction[] = undefined;
  rowIndex: number;
  showDetail: boolean = true;

  constructor(private transServ: TransactionService, private roommateServ : RoommateService,
    private router: Router) { }

  ngOnInit(): void {
    this.getAllTransctions();
  }
 
  getAllTransctions(){
    this.transServ.getAllTransactions(this.roommateServ.loggedInUserPhone).subscribe(
      data =>{
        this.transDetail = data;
        if(this.transDetail && this.transDetail.length>0){
          for(let i=0; i<this.transDetail.length; i++){
            if(this.transDetail[i].transactionBy != this.roommateServ.loggedInUserName){
            this.roommateServ.getByName(this.transDetail[i].transactionBy).subscribe(
              resp =>{
                if(resp && resp.length>0)
                 this.transDetail[i].roommateId = resp[0].phone;
             }
           )
          }
          }
        }
      }
    );

  }

  getTransDetail(transBy : string ,totAmt : number ,cat : string ,transDt : Date, index:number){
    if(!this.showDetail){
     this.transServ.getTransDetails(transBy,totAmt,cat,transDt).subscribe(
       data =>{
         
         for(let detail of data){
           //Get name from phone to display in details
           this.roommateServ.getUserByPhNum(detail.roommateId).subscribe(
            data =>{
              detail.roommateId = data.name;
            },
            err =>{
              detail.roommateId = null;
            }
          )
          
         }
         this.eachTransDetail = data;
         this.rowIndex = index;
         this.showDetail = !this.showDetail;
       }
     )
    }else{
      this.showDetail = !this.showDetail;
      this.rowIndex = this.eachTransDetail.length + 2;
    }
  }
  getNameFromPhone(detail: Transaction){
    this.roommateServ.getUserByPhNum(detail.roommateId).subscribe(
      data =>{
         return data.name;
      },
      err =>{
        return null;
      }
    )
  }

  onClickEdit(){
    this.router.navigate(['/newTrans']);
  }

}
