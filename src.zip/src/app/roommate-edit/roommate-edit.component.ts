import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Roommates } from '../roommates/roommates.model';
import { EventEmitter } from 'events';
import { RoommateService } from '../services/roommateService.service';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-roommate-edit',
  templateUrl: './roommate-edit.component.html',
  styleUrls: ['./roommate-edit.component.css']
})
export class RoommateEditComponent implements OnInit {

  @ViewChild('f') editForm: NgForm;
  roommateToEdit : Roommates;
  editedRoommate : Roommates;
  indexToEdit: number;
  isEdited: boolean = true;
  allRoommates: any;
  invalidEntry: boolean = false;

  errOccured: string;
  updateSuccessful: string;

  constructor(private roommateServ : RoommateService, private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.roommateToEdit = this.roommateServ.roommateToEdit
    this.indexToEdit = this.roommateServ.indexToEdit;
  }

  saveEditDetails(){
    let phoneNumEdited = false;
    //if no details edited and save clicked..dont call service
    if(this.roommateToEdit.name == this.editForm.value.name && this.roommateToEdit.gender == this.editForm.value.gender
      && this.roommateToEdit.phone == this.editForm.value.phone){
        this.isEdited = false;
    }
    //check for duplicate only if phone edited
    if(this.isEdited && this.roommateToEdit.phone != this.editForm.value.phone){
       phoneNumEdited = true;
    }
    //call get all of service to and check no duplicates on edit
    if(phoneNumEdited){
         this.roommateServ.getAll().subscribe(
            data => {
              console.log('GET ALL '+data);
              this.allRoommates = data;
              if(this.allRoommates && this.allRoommates.length > 0){
                for(let i=0; i<this.allRoommates.length; i++){
                  if(this.allRoommates[i].phone == this.editForm.value.phone){
                    this.invalidEntry = true;
                    break;

                  }
                }
              }
            },
            err =>{
              this.errOccured = 'Error occured. Please try again after sometime'
            }
           )
          }
              
              //save new edited fields.
              if(this.isEdited && !this.invalidEntry){
                 let editedRoommate: Roommates = new Roommates('',this.editForm.value.name,this.editForm.value.gender,
                          this.editForm.value.phone, this.roommateToEdit.roomNumber);
                 this.roommateServ.updateRoommate(this.roommateToEdit.phone, editedRoommate).subscribe(
                    data => {
                      if(data){
                        this.editedRoommate = data;
                        this.updateSuccessful = 'Record Updated Successfully'
                      }
                 },
                 err =>{
                  this.errOccured = 'Error occured. Please try again after sometime'
                }
            )
          }

    this.isEdited = true;
   

  }

}
