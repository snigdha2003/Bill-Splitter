import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoommateEditComponent } from './roommate-edit.component';

describe('RoommateEditComponent', () => {
  let component: RoommateEditComponent;
  let fixture: ComponentFixture<RoommateEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoommateEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoommateEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
