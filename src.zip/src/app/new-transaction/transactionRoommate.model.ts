export class TransactionRoommate{

    constructor(public phone: string, public name: string, public youOwe: number, public oweYou: number,
        public toFromName:string, public toFromPhone: string){

        }
}