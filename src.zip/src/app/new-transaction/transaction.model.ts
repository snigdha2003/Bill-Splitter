export class Transaction{

    constructor(public transactionBy: string , public category: string, public createDt: any,
        public totalAmt: number, public roommateId: string, public amount: number, public description: string){}
}