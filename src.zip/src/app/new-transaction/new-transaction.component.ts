import { Component, OnInit, ViewChild } from '@angular/core';
import { RoommateService } from '../services/roommateService.service';
import { Roommates } from '../roommates/roommates.model';
import { TransactionService } from '../services/transaction.service';
import { Transaction } from './transaction.model';
import { NgForm } from '@angular/forms';
import { TransactionRoommate } from './transactionRoommate.model';

@Component({
  selector: 'app-new-transaction',
  templateUrl: './new-transaction.component.html',
  styleUrls: ['./new-transaction.component.css']
})
export class NewTransactionComponent implements OnInit {

  @ViewChild('f') form: NgForm;

  roommates: Roommates[];
  dummyRoomates: number[] = [0];
  allRoommates : Roommates[] = [];
  index: number = 0;
  nameRoommateAdded: string;
  amtAdded: number;
  selfAmt: number;
  namesAddedArr: string[] = [];
  amountAddedArr: number[] = [];

  selectClicked: boolean = false;
  dupRoommateTransError : string;
  amtNotMatchingErr: string;
  calledFromSave: boolean = false;
  splitEqually: boolean = false;

  transactions: Transaction[];
  transactionsToSave: Transaction[]=[];

  errOccurred: string;
  saveSuccessful: string;

  constructor(private roommateServ: RoommateService, private transServ: TransactionService) { }

  ngOnInit(): void {
    this.roommateServ.getByRoomNum(this.roommateServ.loggedInUserRoomNum).subscribe(
      response =>{
        this.roommates = response.slice();
         if(this.roommates){
         this.nameRoommateAdded = this.roommateServ.loggedInUserName;
         this.namesAddedArr.push(this.nameRoommateAdded);
         for(let i=0; i<this.roommates.length;i++){
           if(this.roommates[i].name === this.roommateServ.loggedInUserName){
             this.roommates.splice(i,1);
           }
         }
       }
      //this.roommates.unshift('');
      this.allRoommates = response;
      
      }
    );
   
  }

  getToday(): string {
    console.log(new Date().toISOString().split('T')[0]);
    return new Date().toISOString().split('T')[0]
    //return new Date().toISOString()
  }
  checkDate(event:any){
    if(event.target.value > new Date().toISOString().split('T')[0]){
      console.log(event.target.value);
    }
  }

  selectChangeHandler(event: any, index: number){
    this.selectClicked = true;
    this.dupRoommateTransError = '';
    this.nameRoommateAdded = event.target.value;
    //cant add amt for same roommate again
    if(this.namesAddedArr.includes(this.nameRoommateAdded)){
       this.dupRoommateTransError = 'Cannot add amount to same roommate again.';
    }else{
      this.namesAddedArr[index+1] = event.target.value;
    }
  }
  addRoommateToTrans(){
   this.dupRoommateTransError = '';
   if(!this.selectClicked){
    this.nameRoommateAdded = this.roommates[0].name;
    if(this.form.value.name && this.namesAddedArr.includes(this.nameRoommateAdded)){
          this.dupRoommateTransError = 'Cannot add amount to same roommate again.';
       }
   }
    this.amtAdded = this.form.value.amount;
   
   if(!this.selectClicked &&  this.dupRoommateTransError == ''){
      this.namesAddedArr.push(this.nameRoommateAdded);
     // this.amountAddedArr.push(this.amtAdded);
      // if(!this.calledFromSave){
      //   this.dummyRoomates.push(++this.index);
      // }
   }
   if(this.dupRoommateTransError == ''){
    this.dummyRoomates.push(++this.index);
   }
   this.selectClicked = false;
    
  }

  deleteAddedToTrans(indexToDelete: number){
    this.dummyRoomates.pop();
    let item = this.namesAddedArr[indexToDelete + 1];
    if(this.namesAddedArr.length > indexToDelete + 1){
      this.namesAddedArr = this.namesAddedArr.filter(it => it != item);
      
    }
    if(this.amountAddedArr.length > indexToDelete + 1){
      let amt = this.amountAddedArr[indexToDelete + 1];
      this.amountAddedArr = this.amountAddedArr.filter(am => am != amt);
    }
  }

  saveTrans(){

    if(this.splitEqually){
      let amt = this.form.value.totalAmt/this.allRoommates.length;
      for(let roommate of this.allRoommates){
        let id = this.getPhoneFromName(roommate.name);
        const transacAdded = new Transaction(this.roommateServ.loggedInUserName, this.form.value.expenseCategory, 
          this.form.value.createDt, this.form.value.totalAmt,id,amt, this.form.value.description);
 
        this.transactionsToSave.push(transacAdded);
      }

    }else{

    if(!this.amtNotMatchingErr){
    this.calledFromSave = true;
    //this.amountAddedArr.splice(1,1);
    //to handle last row added-start
    this.addRoommateToTrans();
    //to handle last row added-end
   
    }
    if(this.dupRoommateTransError == ''){
    let amtAdded = 0;
    this.amtNotMatchingErr = '';
    for(let i=0; i<this.amountAddedArr.length; i++){
       amtAdded += this.amountAddedArr[i];
    }
    if(amtAdded != this.form.value.totalAmt){
      this.amtNotMatchingErr = 'Sum of amounts entered per roommate does not match the total amount entered';
    }else{
    let id: string;
    
    for(let j=0; j<this.namesAddedArr.length;j++){
         
             id = this.getPhoneFromName(this.namesAddedArr[j]);
         
         let amt = this.amountAddedArr[j];
         const transacAdded = new Transaction(this.roommateServ.loggedInUserName, this.form.value.expenseCategory, 
          this.form.value.createDt, this.form.value.totalAmt,id,amt, this.form.value.description);
 
        this.transactionsToSave.push(transacAdded);
         
    }
    }
   }
  }
   if(!this.amtNotMatchingErr || this.amtNotMatchingErr == ''){
     this.transServ.saveTransaction(this.transactionsToSave).subscribe(
       data =>{
         this.transactions = data;
         this.saveSuccessful = 'Transaction Saved Successfully';
         if(!this.splitEqually){
           this.splitCalculation(this.form.value.totalAmt, this.namesAddedArr,this.amountAddedArr);
         }
        
       },
        err=>{
           this.errOccurred = 'Error Occurred. Please try again after sometime'
        }
     );
    }

     
    
    this.calledFromSave = false;
    
   
  }

  getPhoneFromName(name: string) : string{
     for(let i=0; i<this.allRoommates.length; i++){
       if(name === this.allRoommates[i].name){
         return this.allRoommates[i].phone;
       }
     }
  }

  onClickSplitEqually(){
    this.splitEqually = !this.splitEqually;
  }

  splitCalculation(totalAmt, names, amounts){
    let transRoommateArr: TransactionRoommate[]=[];
    const shareEachPerson: number = totalAmt/names.length;
   
    let personAmounts = {};
    names.forEach(function(k,i){
        personAmounts[k] = amounts[i];
    })
    const sortedPeople = names.sort((personA, personB) => personAmounts[personA] - personAmounts[personB]);
    const sortedValuesPaid = sortedPeople.map((person) => personAmounts[person] - shareEachPerson);
    console.log("SORTED PEOPLE "+sortedPeople);
    console.log("SORTED VALUES "+sortedValuesPaid);
    let i = 0;
  let j = sortedPeople.length - 1;
  let debt;

  while (i < j) {
    debt = Math.min(-(sortedValuesPaid[i]), sortedValuesPaid[j]);
    sortedValuesPaid[i] += debt;
    sortedValuesPaid[j] -= debt;

    console.log(`${sortedPeople[i]} owes ${sortedPeople[j]} $${debt}`);
    if(debt != 0){
    let transRoommate = new TransactionRoommate(this.getPhoneFromName(sortedPeople[i]),sortedPeople[i], debt, 0, sortedPeople[j],
       this.getPhoneFromName(sortedPeople[j]));
    transRoommateArr.push(transRoommate);
    }

    if (sortedValuesPaid[i] === 0) {
      i++;
    }

    if (sortedValuesPaid[j] === 0) {
      j--;
    }

    
    
  }
  if(transRoommateArr.length > 0){
    this.transServ.saveTransRoommate(transRoommateArr).subscribe(
      data =>{
        console.log('SAVED TRANROOMMATE '+data);
      }
    )
  }

  }

  amtChanged(event: any, index: number){
    console.log("CHANGE AMT: "+event.target.value, "INDEX "+index);
    if(this.selfAmt != this.form.value.amountSelf){
      this.selfAmt = this.form.value.amountSelf;
      this.amountAddedArr.unshift(this.selfAmt);
    }
    this.amountAddedArr[index+1] = +event.target.value;
    console.log("1st val "+this.amountAddedArr[0]);
  }

  
  
}
