export class Roommates{

    constructor(public id: string, public name:string, public gender: string, public phone: string,
        public roomNumber: string){
        
    }

    getIdFromName( roommate: Roommates): string{
       return roommate.id;
    }
}