import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';
import { Roommates } from './roommates.model';
import { NgForm } from '@angular/forms';
import { RoommateService } from '../services/roommateService.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-roommates',
  templateUrl: './roommates.component.html',
  styleUrls: ['./roommates.component.css']
})
export class RoommatesComponent implements OnInit {

 
  @ViewChild('f') signUpForm: NgForm;

  roommates: Roommates[] = [
    new Roommates('111','Joey','Male','8963821334','123456')

  ];
  newRoommates: Roommates[] = [];
  roommatesToSave: Roommates[] = [];

  addNew: boolean = false;
  name: string;
  gender: string;
  phone: string;
  addedToroommates: boolean = false;
  invalidEntry: boolean = false;
  roomNum: string;

  isSaveClicked: boolean = false;

  disableAdd: boolean;
  saveSuccessful: string;
  errorOnSave: string;
  deleteSuccessful: string;
  

  constructor(private roommateServ: RoommateService, private activeRoute: ActivatedRoute,
               private router: Router) { }

  ngOnInit(): void {
    
    this.getAllRoommates();
  }

  getAllRoommates(){
    this.roommateServ.getByRoomNum(this.roommateServ.loggedInUserRoomNum).subscribe(
      data =>{
        this.roommates = data;
        if(data.length == 6){
          this.disableAdd = true;
        }else{
          this.disableAdd = false;
        }
      }
    );
  }

  saveDetails(){
    this.phone = this.signUpForm.value.phone;
    this.isSaveClicked = true;
    for(let i=0; i<this.roommates.length; i++){
      if(this.roommates[i].phone == this.phone){
        this.invalidEntry = true;
      }
    }
    for(let i=0; i<this.roommatesToSave.length;i++){
      if(this.roommatesToSave[i].phone == this.phone){
        this.invalidEntry = true;
      }
    }
   if(!this.invalidEntry){
    //when clicked on save w/o clicking add new-start
    if(this.signUpForm.value.name){
    this.name = this.signUpForm.value.name;
    this.gender = this.signUpForm.value.gender;
    this.roomNum = this.roommateServ.loggedInUserRoomNum;
    const roommateAdded = new Roommates('',this.name, this.gender, this.phone, this.roomNum);
    this.roommatesToSave.push(roommateAdded);
    this.roommates.push(roommateAdded);
    }
    //when clicked on save w/o clicking add new-end
    this.roommateServ.saveRoommates(this.roommatesToSave).subscribe(
      data =>{
        if(data){
          this.saveSuccessful = 'Save Successful';
        }
      },
     err =>{
      this.errorOnSave = 'Error occurred. Please try after sometime'
     } 
    );
   }
   this.roommatesToSave = [];
   this.newRoommates = [];
  }

  onClickAddNew(){
    this.invalidEntry = false;
    let blankRoommate = new Roommates('','','','','');
    if(this.signUpForm.value.name){
    this.addedToroommates = true;
    this.name = this.signUpForm.value.name;
    this.gender = this.signUpForm.value.gender;
    this.phone = this.signUpForm.value.phone;
    this.roomNum = this.roommateServ.loggedInUserRoomNum;
    for(let i=0; i<this.roommates.length; i++){
      if(this.roommates[i].phone == this.phone){
        this.invalidEntry = true;
      }
    }
    for(let i=0; i<this.roommatesToSave.length;i++){
      if(this.roommatesToSave[i].phone == this.phone){
        this.invalidEntry = true;
      }
    }
    if(!this.invalidEntry && this.roommates.length != 6){
    const roommateAdded = new Roommates('',this.name, this.gender, this.phone, this.roomNum);
    this.roommatesToSave.push(roommateAdded);
    this.roommates.push(roommateAdded);
    }
    }
    if(!this.invalidEntry && this.roommates.length != 6){
    this.newRoommates = [];
    this.newRoommates.push(blankRoommate);
    }
    if(this.roommates.length == 6){
      this.disableAdd = true;
    }
  }

  onClickDelete(indexToDelete: number){
    console.log('Delete '+indexToDelete);
    if(indexToDelete != -1){
       this.roommateServ.deleteRoommate(this.roommates[indexToDelete]).subscribe(
         data =>{
           this.deleteSuccessful = 'Record Deleted successfully'
           this.saveSuccessful = '';
           this.getAllRoommates();
        },
        err=>{
          this.errorOnSave = 'Error occurred. Please try after sometime'
        }
      );
    }else if(indexToDelete == -1){
      this.newRoommates = this.newRoommates.splice(1,1);
    }
    if(this.roommates.length != 6){
      this.disableAdd = false;
    }
  }

  onClickEdit(roommateToEdit: Roommates, indexToEdit: number){
    this.roommateServ.roommateToEdit = roommateToEdit;
    this.roommateServ.indexToEdit = indexToEdit;
    this.router.navigate(['/edit']);

  }
  

}
