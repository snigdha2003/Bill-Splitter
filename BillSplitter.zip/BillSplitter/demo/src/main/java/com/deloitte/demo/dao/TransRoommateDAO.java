package com.deloitte.demo.dao;

import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

@CrossOrigin("http://localhost:4200")
@Repository
public class TransRoommateDAO {
	
	public Aggregation customQueryOweYou(String phone) {
		
		//get all owe you(logged in user)
		MatchOperation nameMatch =
				Aggregation.match(new Criteria("toFromPhone").is(phone));
		GroupOperation  groupByToFromNamew =
				Aggregation.group("toFromPhone").sum("youOwe").as("youOwe");
		Aggregation aggregateOweYou = newAggregation(nameMatch, groupByToFromNamew);
		return aggregateOweYou;
	}
	
	public Aggregation customQueryYouOwe(String phone) {
		//Get all you(logged in used) owe
		MatchOperation nameMatch =
				Aggregation.match(new Criteria("phone").is(phone));
		GroupOperation groupByToFromNamew =
				Aggregation.group("phone").sum("youOwe").as("youOwe");
		Aggregation aggregateYouOwe = newAggregation(nameMatch, groupByToFromNamew);
		return aggregateYouOwe;
		
		
	}

}
