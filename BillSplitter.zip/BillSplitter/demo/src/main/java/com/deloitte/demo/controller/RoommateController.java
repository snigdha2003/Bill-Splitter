package com.deloitte.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.demo.dao.TransRoommateDAO;
import com.deloitte.demo.entiry.Roommates;
import com.deloitte.demo.entiry.TransRoommate;
import com.deloitte.demo.entiry.Transactions;
import com.deloitte.demo.repository.RommmateRepository;
import com.deloitte.demo.repository.TransRoommateRepository;
import com.deloitte.demo.repository.TransactionRepository;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api")
public class RoommateController {
	
	@Autowired
	RommmateRepository roommateRepo;
	
	@Autowired
	TransactionRepository transacRepo;
	
	@Autowired
	TransRoommateRepository transRoommateRepo;
	
	
	  @Autowired TransRoommateDAO dao;
	 
	
	@Autowired
	MongoTemplate mongoTemp;
	
	@PostMapping("/roommates")
	public List<Roommates> createRoommates(@RequestBody List<Roommates> roommateList){
	
		List<Roommates> savedRoommateList = roommateRepo.saveAll(roommateList);
		System.out.print("INSIDEEE PPOST::::: ");
		return savedRoommateList; 
	}
	@GetMapping("/getAllRoommates")
	public List<Roommates> getAll() {
		List<Roommates> allRommates = new ArrayList<Roommates>();
		roommateRepo.findAll().forEach(allRommates::add);
		System.out.print("INSIDEEE GETALL::::::: ");
		return allRommates;
	}
	@GetMapping("/getUserByPhone/{phone}")
	public Roommates getUserByPhone(@PathVariable("phone") String phone) {
		return roommateRepo.findByPhone(phone);
	}
	@GetMapping("/getByRoomNum/{roomNum}")
	public List<Roommates> getByRoomNum(@PathVariable("roomNum") String roomNum){
		List<Roommates> list = roommateRepo.findByRoomNumber(roomNum);
		System.out.println("LENGTH OF USER FOR ROOMNUM "+ list.size());
		return list;
	}
	@GetMapping("/getByName/{name}")
	public List<Roommates> getByName(@PathVariable String name){
		List<Roommates> list = roommateRepo.findByName(name);
		System.out.println("LENGTH OF USER FOR NAME "+ list.size());
		return list;
	}
	@PutMapping("/editRoommate/{phone}")
	public Roommates editRoommates(@RequestBody Roommates editedRoommate, 
			@PathVariable String phone){
		Roommates roommate = roommateRepo.findByPhone(phone);
		if(null != roommate) {
			roommate.setName(editedRoommate.getName());
			roommate.setGender(editedRoommate.getGender());
			roommate.setPhone(editedRoommate.getPhone());
			roommate.setRoomNumber(editedRoommate.getRoomNumber());
			return roommateRepo.save(roommate);
		}else {
			return null;
		}
		
	}
	@DeleteMapping("/deleteRoommate/{phone}")
	public Long deleteRoommateByPhone(@PathVariable String phone) {
		
		return roommateRepo.deleteByPhone(phone);
	}
	
	//Transactions related
	@PostMapping("/transactions")
	public List<Transactions> createTransaction(@RequestBody List<Transactions> transactionList){
	
		List<Transactions> savedTransactionList = transacRepo.saveAll(transactionList);
		System.out.print("INSIDEEE PPOST TRANSACTIONS::::: ");
		return savedTransactionList; 
	}
	
	@GetMapping("/transacSumm/{phone}")
	public List<TransRoommate> getTransacSumm(@PathVariable String phone) {
		Aggregation aggregate = dao.customQueryOweYou(phone);
		System.out.println("Query  ==>>["+aggregate.toString()+"]");
		AggregationResults<TransRoommate> queryResult = mongoTemp.aggregate(aggregate, "transRoommate", TransRoommate.class);
		aggregate = dao.customQueryYouOwe(phone);
		System.out.println("Query2  ==>>["+aggregate.toString()+"]");
		AggregationResults<TransRoommate> queryResult2 = mongoTemp.aggregate(aggregate, "transRoommate", TransRoommate.class);
		List result = new ArrayList<>();
		if (null != queryResult && null != queryResult.getMappedResults() && !queryResult.getMappedResults().isEmpty()) {
			result.add(queryResult.getMappedResults().get(0));
		}else {
			
			result.add(new TransRoommate());
		}
		if (null != queryResult2 && null != queryResult2.getMappedResults() && !queryResult2.getMappedResults().isEmpty()) {
			result.add(queryResult2.getMappedResults().get(0));
		}else {
			result.add(new TransRoommate());
		}
		return result;
	}
	 
	
	
	  @GetMapping("/allTransactions/{roommatePhone}") 
	  public List<Transactions> getAllTRansactions(@PathVariable String roommatePhone) { 
		  return transacRepo.findByRoommateId(roommatePhone);
	  }
	  
	  @GetMapping("/transDetails/{transBy}/{totAmt}/{cat}/{date}")
	  public List<Transactions> getTransDetails(@PathVariable String transBy, @PathVariable long totAmt,
			  @PathVariable String cat, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Date date){
		  return transacRepo.findByTransactionByAndTotalAmtAndCategoryAndCreateDt(transBy, totAmt, cat, date);
		  //return transacRepo.findByTransactionByAndTotalAmtAndCategory(transBy, totAmt, cat);
		  
	  }
	  
	 
	
	//Transaction-Roommate
	@PostMapping("/transRoommate")
	public List<TransRoommate> saveTransRoommate(@RequestBody List<TransRoommate> transRoomArr){
		return transRoommateRepo.saveAll(transRoomArr); 
	}
	
	@GetMapping("/transacListYouOwe/{loggedInUser}")
	public List<TransRoommate> getTransListYouOwe(@PathVariable("loggedInUser") String phone){
		return transRoommateRepo.findByPhone(phone); 
	}
	
	@GetMapping("/transacListOweYou/{loggedInUser}")
	public List<TransRoommate> getTransListOweYou(@PathVariable("loggedInUser") String phone){
		return transRoommateRepo.findByToFromPhone(phone); 
	}
	

}
