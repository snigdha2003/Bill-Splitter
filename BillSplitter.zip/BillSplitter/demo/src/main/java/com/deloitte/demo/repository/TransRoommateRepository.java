package com.deloitte.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deloitte.demo.entiry.TransRoommate;
import com.deloitte.demo.entiry.Transactions;

public interface TransRoommateRepository extends MongoRepository<TransRoommate, String> {
	List<TransRoommate> findByPhone(String phone);
	List<TransRoommate> findByToFromPhone(String phone);

}
