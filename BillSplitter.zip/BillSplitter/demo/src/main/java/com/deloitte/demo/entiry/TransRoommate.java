package com.deloitte.demo.entiry;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class TransRoommate {
	
	private String id;
	private String phone;
	private String name;
	private long youOwe;
	private long oweYou;
	private String toFromName;
	private String toFromPhone;
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getYouOwe() {
		return youOwe;
	}
	public void setYouOwe(long youOwe) {
		this.youOwe = youOwe;
	}
	public long getOweYou() {
		return oweYou;
	}
	public void setOweYou(long oweYou) {
		this.oweYou = oweYou;
	}
	public String getToFromName() {
		return toFromName;
	}
	public void setToFromName(String toFromName) {
		this.toFromName = toFromName;
	}
	public String getToFromPhone() {
		return toFromPhone;
	}
	public void setToFromPhone(String toFromPhone) {
		this.toFromPhone = toFromPhone;
	}
	
	
	
	
	

}
