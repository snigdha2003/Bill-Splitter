package com.deloitte.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deloitte.demo.entiry.Transactions;

public interface TransactionRepository extends MongoRepository<Transactions, String> {
	List<Transactions> findByRoommateId(String phone);
	List<Transactions> findByTransactionByAndTotalAmtAndCategoryAndCreateDt(String transBy, long totAmt, String cat, Date transDt);
	List<Transactions> findByTransactionByAndTotalAmtAndCategory(String transBy, long totAmt, String cat);

}
