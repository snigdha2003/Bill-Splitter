package com.deloitte.demo.repository;



import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.demo.entiry.Roommates;

@CrossOrigin("http://localhost:4200")
public interface RommmateRepository extends MongoRepository<Roommates, String> {
	
	Page<Roommates> findById(@RequestParam("id") Long id, Pageable pageable);
	Roommates findByPhone(@RequestParam("phone") String phone);
	List<Roommates> findByRoomNumber(@RequestParam("roomNum") String roomNum);
	List<Roommates> findByName(@RequestParam("name") String name);
	Long deleteByPhone(String phoneNum);

	
}
