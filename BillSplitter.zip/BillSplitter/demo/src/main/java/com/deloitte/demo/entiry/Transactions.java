package com.deloitte.demo.entiry;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class Transactions {
	
	@Id
	private String id;
	private String transactionBy;
	private String category;
	private Date createDt;
	private long totalAmt;
	private String roommateId;
	private long amount;
	private String description;
	
	public String getTransactionBy() {
		return transactionBy;
	}
	public void setTransactionBy(String transactionBy) {
		this.transactionBy = transactionBy;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Date getCreateDt() {
		return createDt;
	}
	public void setCretaeDt(Date createDt) {
		this.createDt = createDt;
	}
	public long getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(long totalAmt) {
		this.totalAmt = totalAmt;
	}
	public String getRoommateId() {
		return roommateId;
	}
	public void setRoommateId(String roommateId) {
		this.roommateId = roommateId;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	

}
